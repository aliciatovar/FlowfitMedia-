export interface NicheInfo {
  id: string;
  title: string;
  subtitle: string;
  icon: string; // Lucide icon name
  seoKeywords: string[];
  painPoints: string[];
  solutions: string[];
  caseStudyMock: {
    client: string;
    metrics: string;
    duration: string;
    quote: string;
  };
}

export interface PricingPlan {
  id: string;
  name: string;
  price: string;
  description: string;
  features: string[];
  badge?: string;
  isPopular?: boolean;
}

export interface FaqItem {
  question: string;
  answer: string;
  seoKeywordFocus: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  businessName: string;
  businessType: string;
  website: string;
  currentClients: string;
  biggestChallenge: string;
  acceptTerms: boolean;
}
