import React from 'react';
import { Award, Flame, Users, CalendarCheck2 } from 'lucide-react';

export default function BrandStory() {
  return (
    <section id="historia" className="py-24 bg-slate-50 border-t border-b border-slate-200 relative">
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left column - personal text story */}
          <div className="lg:col-span-7 space-y-6 order-1 lg:order-1">
            <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 px-3 py-1 rounded-full">
              Nuestra Historia & Misión
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              La Filosofía Detrás de FlowfitMedia Agency
            </h2>

            <blockquote className="border-l-4 border-indigo-600 pl-6 italic text-slate-700 text-base leading-relaxed bg-white border border-slate-200 p-5 rounded-r-xl shadow-sm">
              "Hubo un tiempo en el que trabajaba durante horas sin ver reflejado ese esfuerzo en mi cuenta bancaria. Vivía convencido de que trabajar más era la única forma de ganar más. Todo cambió el día que decidí abrir mi propia agencia."
            </blockquote>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
              <div className="space-y-2">
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></span>
                  El Punto de Inflexión
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Comprendí que el problema no era mi capacidad para trabajar duro, sino el modelo de negocio que estaba siguiendo. Dejé de vender simplemente mi tiempo por horas sueltas y empecé a crear un negocio guiado por una visión real, estrategia sólida y propósito de impacto.
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                  La Misión Hoy
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Acompañar a empresas de salud y deportivas que quieren dejar de preocuparse por "sobrevivir" al mes para empezar a crecer de verdad. Analizamos tu potencial latente, detectamos fugas de clientes y desarrollamos estrategias de conversión que te permiten vender más y escalar sin límite.
                </p>
              </div>
            </div>

            <div className="bg-indigo-50/50 border border-indigo-100 p-4 rounded-xl text-xs text-slate-750 italic">
              "Si yo pude cambiar mi realidad, también quiero ayudar a que otros cambien la suya. Cuando cambia la estrategia, cambian los resultados. Y cuando cambian los resultados, también puede cambiar una vida entera."
            </div>
          </div>

          {/* Right column - Values and stats */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-4 order-2 lg:order-2">
            <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm">
              <span className="p-2 bg-indigo-50 text-indigo-600 rounded-lg inline-block mb-3">
                <Flame className="w-5 h-5 animate-pulse" />
              </span>
              <h4 className="text-2xl font-black text-slate-900">100%</h4>
              <p className="text-slate-400 text-xs uppercase font-mono tracking-wider mt-1">Especializados</p>
              <p className="text-slate-500 text-xs mt-2">Dedicados de forma exclusiva a deporte y salud.</p>
            </div>

            <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm">
              <span className="p-2 bg-emerald-50 text-emerald-600 rounded-lg inline-block mb-3">
                <Users className="w-5 h-5" />
              </span>
              <h4 className="text-2xl font-black text-slate-900">+12k</h4>
              <p className="text-slate-400 text-xs uppercase font-mono tracking-wider mt-1">Citas Generadas</p>
              <p className="text-slate-500 text-xs mt-2">Reservas directas gestionadas por nuestros embudos.</p>
            </div>

            <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm">
              <span className="p-2 bg-amber-50 text-amber-600 rounded-lg inline-block mb-3">
                <CalendarCheck2 className="w-5 h-5" />
              </span>
              <h4 className="text-2xl font-black text-slate-900">Agenda</h4>
              <p className="text-slate-400 text-xs uppercase font-mono tracking-wider mt-1">Siempre Llena™</p>
              <p className="text-slate-500 text-xs mt-2">Metodología de optimización patentada y probada.</p>
            </div>

            <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm">
              <span className="p-2 bg-blue-50 text-blue-600 rounded-lg inline-block mb-3">
                <Award className="w-5 h-5" />
              </span>
              <h4 className="text-2xl font-black text-slate-900">4.9/5</h4>
              <p className="text-slate-400 text-xs uppercase font-mono tracking-wider mt-1">Puntuación de Socios</p>
              <p className="text-slate-500 text-xs mt-2">Satisfacción de marcas y profesionales médicos.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
