import React, { useState, useEffect } from 'react';
import { Target, MessageSquare, Award, ArrowRight, Menu, X, ShieldCheck } from 'lucide-react';

interface NavbarProps {
  onScrollToSection: (sectionId: string) => void;
}

export default function Navbar({ onScrollToSection }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { label: 'Especialidades', id: 'especialidades' },
    { label: '¿Te identificas?', id: 'persona' },
    { label: 'Método Agenda Llena', id: 'metodo' },
    { label: 'Calculadora ROI', id: 'calculadora' },
    { label: 'Planes', id: 'planes' },
    { label: 'Nuestra Historia', id: 'historia' },
    { label: 'Preguntas', id: 'faqs' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/95 backdrop-blur-md border-b border-slate-200 py-3 shadow-sm' : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo / Brand Name */}
          <div 
            onClick={() => onScrollToSection('hero')} 
            className="flex items-center space-x-2 cursor-pointer group"
          >
            <div className="relative w-10 h-10 flex items-center justify-center bg-indigo-600 rounded-lg overflow-hidden transition-transform duration-300 group-hover:scale-110">
              <span className="font-extrabold text-white text-xl tracking-tighter">FF</span>
              <div className="absolute inset-0 bg-gradient-to-tr from-black/20 to-transparent"></div>
            </div>
            <div>
              <span className="font-bold text-slate-900 text-lg tracking-wider block">
                FLOWFIT<span className="text-indigo-600">MEDIA</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono uppercase tracking-widest block -mt-1">
                Performance Agency
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onScrollToSection(item.id)}
                className="text-slate-600 hover:text-indigo-600 text-xs font-semibold tracking-wide uppercase transition-colors duration-200"
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Action Button */}
          <div className="hidden sm:block">
            <button
              onClick={() => onScrollToSection('contacto')}
              className="relative overflow-hidden group bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-md font-bold text-xs uppercase tracking-wider transition-all duration-300 flex items-center space-x-2 shadow-sm shadow-indigo-100"
            >
              <span>Auditoría Gratuita</span>
              <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="lg:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-600 hover:text-slate-900 focus:outline-none p-2"
              aria-label="Toggle Menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {isOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 py-4 px-6 absolute top-full left-0 w-full animate-fadeIn shadow-lg">
          <div className="flex flex-col space-y-4">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onScrollToSection(item.id);
                  setIsOpen(false);
                }}
                className="text-slate-600 hover:text-indigo-600 text-sm font-semibold tracking-wider uppercase text-left py-2 border-b border-slate-100"
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => {
                onScrollToSection('contacto');
                setIsOpen(false);
              }}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-md font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 shadow-md shadow-indigo-100 mt-2"
            >
              <span>Auditoría Gratuita</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
