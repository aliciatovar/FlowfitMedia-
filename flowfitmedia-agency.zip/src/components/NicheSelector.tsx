import React, { useState } from 'react';
import { NICHES } from '../data';
import { NicheInfo } from '../types';
import { Activity, Dumbbell, Heart, Apple, Award, Search, HelpCircle, CheckCircle, TrendingUp } from 'lucide-react';

export default function NicheSelector() {
  const [activeNicheId, setActiveNicheId] = useState<string>('fisioterapia');

  const activeNiche = NICHES.find((n) => n.id === activeNicheId) || NICHES[0];

  // Map icon name string to Lucide component
  const getIcon = (iconName: string, className: string) => {
    switch (iconName) {
      case 'Activity':
        return <Activity className={className} />;
      case 'Dumbbell':
        return <Dumbbell className={className} />;
      case 'Heart':
        return <Heart className={className} />;
      case 'Apple':
        return <Apple className={className} />;
      case 'Award':
        return <Award className={className} />;
      default:
        return <Activity className={className} />;
    }
  };

  return (
    <section id="especialidades" className="py-24 bg-slate-50 relative border-b border-slate-200">
      <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 px-3 py-1 rounded-full">
            Especialistas del Sector Deporte y Salud
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mt-4">
            Estrategias de Marketing Diseñadas para tu Nicho Exacto
          </h2>
          <p className="text-slate-600 mt-4 text-sm sm:text-base">
            No creemos en soluciones genéricas de marketing. Cada disciplina dentro del deporte y el bienestar tiene su propio embudo de conversión, normativas específicas y perfiles de cliente únicos.
          </p>
        </div>

        {/* Niche Buttons Selector Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-12">
          {NICHES.map((niche) => {
            const isActive = niche.id === activeNicheId;
            return (
              <button
                key={niche.id}
                onClick={() => setActiveNicheId(niche.id)}
                className={`flex flex-col items-center justify-center p-5 rounded-xl border text-center transition-all duration-300 cursor-pointer ${
                  isActive
                    ? 'bg-indigo-50/50 border-indigo-600 shadow-sm shadow-indigo-100'
                    : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                <div className={`p-3 rounded-lg mb-3 transition-colors duration-300 ${
                  isActive ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500'
                }`}>
                  {getIcon(niche.icon, 'w-6 h-6')}
                </div>
                <span className={`text-xs sm:text-sm font-bold tracking-wide transition-colors ${
                  isActive ? 'text-indigo-950' : 'text-slate-600'
                }`}>
                  {niche.title}
                </span>
              </button>
            );
          })}
        </div>

        {/* Active Niche Dynamic Dashboard */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-10 shadow-sm relative overflow-hidden animate-fadeIn">
          {/* Subtle branding stripe */}
          <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-indigo-600 via-indigo-400 to-transparent"></div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Info Column */}
            <div className="lg:col-span-7 space-y-8">
              <div>
                <span className="text-xs font-mono font-bold text-indigo-600 uppercase tracking-widest block mb-2">
                  {activeNiche.subtitle}
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                  Cómo Llenamos la Agenda de un {activeNiche.title}
                </h3>
              </div>

              {/* SEO Keywords Tag Cloud (Expert Insight) */}
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl">
                <div className="flex items-center gap-2 mb-3">
                  <Search className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-mono uppercase font-bold text-slate-900 tracking-wider">
                    Palabras Clave SEO de Alta Intención Comercial
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {activeNiche.seoKeywords.map((kw, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] font-mono font-semibold bg-white border border-slate-200 text-slate-700 px-2.5 py-1 rounded-md"
                    >
                      "{kw}"
                    </span>
                  ))}
                </div>
                <p className="text-[10px] text-slate-500 mt-2 italic">
                  *Estas palabras clave representan búsquedas locales reales de clientes con tarjeta en mano listos para reservar.
                </p>
              </div>

              {/* Pain vs Solution Columns */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Pain Points */}
                <div className="space-y-3">
                  <h4 className="text-xs font-mono uppercase tracking-widest text-rose-600 font-extrabold flex items-center gap-2">
                    <HelpCircle className="w-4 h-4" /> Los Problemas Comunes
                  </h4>
                  <ul className="space-y-2.5">
                    {activeNiche.painPoints.map((pain, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-600 leading-relaxed">
                        <span className="text-rose-500 font-bold mt-0.5">•</span>
                        <span>{pain}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Solutions */}
                <div className="space-y-3">
                  <h4 className="text-xs font-mono uppercase tracking-widest text-emerald-600 font-extrabold flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" /> Nuestra Solución Flowfit
                  </h4>
                  <ul className="space-y-2.5">
                    {activeNiche.solutions.map((sol, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-700 leading-relaxed">
                        <span className="text-emerald-500 font-bold mt-0.5">✓</span>
                        <span>{sol}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Right Case Study Sidebar Column */}
            <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-6 relative overflow-hidden self-center shadow-lg">
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-indigo-500/10 rounded-full blur-2xl"></div>
              
              <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] font-mono font-bold tracking-widest text-indigo-400 uppercase bg-indigo-500/10 px-2 py-0.5 rounded">
                  CASO DE ÉXITO REAL
                </span>
                <span className="text-xs font-mono font-semibold text-slate-400">
                  {activeNiche.caseStudyMock.duration}
                </span>
              </div>

              <h4 className="text-lg font-bold text-white mb-1">
                {activeNiche.caseStudyMock.client}
              </h4>
              
              {/* Highlight Metric */}
              <div className="my-4 flex items-baseline gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
                <span className="text-3xl font-extrabold text-white tracking-tight">
                  {activeNiche.caseStudyMock.metrics}
                </span>
              </div>

              <blockquote className="border-l-2 border-indigo-500 pl-4 italic text-xs text-slate-300 leading-relaxed">
                "{activeNiche.caseStudyMock.quote}"
              </blockquote>

              <div className="mt-6 pt-4 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
                <span>Director de Estrategia: FlowfitMedia</span>
                <span className="text-emerald-400 font-bold">100% Verificado</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
