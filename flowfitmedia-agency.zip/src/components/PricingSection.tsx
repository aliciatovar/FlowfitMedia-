import React, { useState } from 'react';
import { PRICING_PLANS } from '../data';
import { Check, Info, ShieldAlert, Sparkles, PhoneCall, HelpCircle } from 'lucide-react';

export default function PricingSection() {
  const [isAnnual, setIsAnnual] = useState<boolean>(false);

  // Prices of setup
  const setups: { [key: string]: string } = {
    esencial: '0 € (Sin Setup)',
    crecimiento: '2.000 € (Configuración única)',
    premium: '4.000 € - 6.000 € (Llave en mano)',
  };

  // Mantenimiento prices
  const monthlyMaintenance: { [key: string]: string } = {
    esencial: '700',
    crecimiento: '900',
    premium: '1.200 - 1.500',
  };

  return (
    <section id="planes" className="py-24 bg-slate-50 border-t border-b border-slate-200 relative overflow-hidden">
      {/* Decorative backdrop elements */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 px-3.5 py-1.5 rounded-full border border-indigo-100 shadow-sm">
            Estrategias de Captación & Retorno
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mt-6 leading-tight">
            Sistemas Estratégicos con <span className="text-indigo-600 bg-clip-text">Garantía de Retorno</span>
          </h2>
          <p className="text-slate-650 mt-4 text-base sm:text-lg leading-relaxed">
            No vendemos "publicaciones estéticas" aisladas. Implementamos <strong className="text-slate-900">estrategias integrales de captación y optimización de agenda</strong> diseñadas para amortizarse desde el primer mes y escalar tus ingresos de forma medible.
          </p>
        </div>

        {/* Pricing Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-10 items-stretch mb-20">
          {PRICING_PLANS.map((plan) => {
            const setupCost = setups[plan.id];
            const maintenanceCost = monthlyMaintenance[plan.id];
            
            // Strategic Impact label and style config based on plan
            const planConfigs: { [key: string]: { impact: string; accentColor: string; shadowClass: string } } = {
              esencial: {
                impact: 'Impacto: Visibilidad & Presencia de Marca',
                accentColor: 'text-slate-700 bg-slate-100 border-slate-200',
                shadowClass: 'hover:shadow-xl hover:shadow-slate-100/50 hover:border-slate-300'
              },
              crecimiento: {
                impact: 'Impacto: Captación Acelerada de Pacientes/Socios',
                accentColor: 'text-indigo-700 bg-indigo-50 border-indigo-100',
                shadowClass: 'shadow-2xl shadow-indigo-100/70 border-indigo-600 ring-4 ring-indigo-50 lg:scale-[1.04]'
              },
              premium: {
                impact: 'Impacto: Automatización Completa & Dominio Local',
                accentColor: 'text-emerald-700 bg-emerald-50 border-emerald-100',
                shadowClass: 'hover:shadow-xl hover:shadow-emerald-100/40 hover:border-emerald-300'
              }
            };

            const config = planConfigs[plan.id] || planConfigs.esencial;

            return (
              <div
                key={plan.id}
                className={`rounded-3xl border p-6 sm:p-10 flex flex-col justify-between transition-all duration-300 relative bg-white ${config.shadowClass}`}
              >
                {/* Popular / Best Strategy Badge */}
                {plan.isPopular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 flex items-center gap-1.5 bg-indigo-600 text-white text-[11px] font-mono font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-md shadow-indigo-200">
                    <Sparkles className="w-3.5 h-3.5 animate-spin-slow" />
                    <span>{plan.badge}</span>
                  </div>
                )}

                <div>
                  {/* Strategic Impact Badge */}
                  <span className={`inline-block text-[10px] font-mono font-bold uppercase tracking-wider px-3 py-1 rounded-full border mb-4 ${config.accentColor}`}>
                    {config.impact}
                  </span>

                  <h3 className={`text-xl sm:text-2xl font-black tracking-tight mb-2 ${
                    plan.isPopular ? 'text-indigo-950' : 'text-slate-900'
                  }`}>
                    {plan.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 leading-relaxed mb-6 min-h-[48px]">
                    {plan.description}
                  </p>

                  {/* Pricing displays */}
                  <div className={`p-5 rounded-2xl border mb-6 transition-all duration-300 ${
                    plan.isPopular 
                      ? 'bg-gradient-to-br from-indigo-50/70 to-white border-indigo-200/80 shadow-inner' 
                      : 'bg-slate-50/50 border-slate-200/75'
                  }`}>
                    <div className="flex items-baseline gap-1.5 mb-2">
                      <span className={`text-4xl sm:text-5xl font-black tracking-tight ${
                        plan.isPopular ? 'text-indigo-600' : 'text-slate-900'
                      }`}>
                        {maintenanceCost} €
                      </span>
                      <span className="text-xs text-slate-500 font-semibold uppercase font-mono">
                        / Mes Mantenimiento
                      </span>
                    </div>
                    
                    <div className="flex items-start gap-2 text-xs text-slate-650 font-medium leading-normal pt-2 border-t border-slate-200/50 mt-2">
                      <Info className={`w-4 h-4 shrink-0 mt-0.5 ${plan.isPopular ? 'text-indigo-600' : 'text-slate-400'}`} />
                      <span>Inversión de Setup (Configuración inicial única): <strong className="text-slate-900 font-bold">{setupCost}</strong></span>
                    </div>
                  </div>

                  {/* Divider */}
                  <div className={`border-t my-6 ${plan.isPopular ? 'border-indigo-100' : 'border-slate-100'}`}></div>

                  {/* Feature Checklist */}
                  <span className={`text-xs font-mono font-bold uppercase tracking-wider block mb-4 ${
                    plan.isPopular ? 'text-indigo-900' : 'text-slate-800'
                  }`}>
                    Pilares de la Estrategia:
                  </span>
                  
                  <ul className="space-y-3.5 mb-8">
                    {plan.features.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <div className={`p-0.5 rounded-full mt-0.5 shrink-0 ${
                          plan.isPopular ? 'bg-indigo-100 text-indigo-700' : 'bg-emerald-100 text-emerald-700'
                        }`}>
                          <Check className="w-3.5 h-3.5 stroke-[3px]" />
                        </div>
                        <span className={`text-xs sm:text-sm leading-normal font-medium ${
                          plan.isPopular ? 'text-slate-700' : 'text-slate-600'
                        }`}>
                          {feat}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Call to action */}
                <a
                  href="#contacto"
                  className={`w-full text-center font-bold text-xs sm:text-sm uppercase tracking-wider py-4 rounded-xl transition-all duration-300 block shadow-sm ${
                    plan.isPopular
                      ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-200 hover:-translate-y-0.5'
                      : 'bg-slate-900 hover:bg-slate-950 text-white hover:-translate-y-0.5'
                  }`}
                >
                  Solicitar esta Estrategia
                </a>
              </div>
            );
          })}
        </div>

        {/* Sales Pitch Banner (Under the grid, directly from PDF page 6) */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-lg text-white">
          <div className="space-y-2">
            <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase bg-indigo-500/10 px-2.5 py-0.5 rounded">
              Script de Consultoría Recomendado
            </span>
            <h4 className="text-lg font-bold text-white tracking-tight">
              "José, lo que necesitas no es publicar más en redes..."
            </h4>
            <p className="text-slate-300 text-xs sm:text-sm max-w-3xl leading-relaxed">
              ...Sino un sistema que atraiga nuevos pacientes de forma constante. La inversión es de 2.000 € para implementar tu embudo de captación automatizado a medida y 900 €/mes de mantenimiento para que optimicemos tus anuncios, organicemos tus contenidos y llenemos tu agenda en piloto automático.
            </p>
          </div>
          <div className="shrink-0">
            <div className="bg-indigo-500/10 border border-indigo-500/20 p-4 rounded-xl flex items-center gap-3">
              <span className="text-2xl">🤝</span>
              <div>
                <span className="text-[11px] font-mono font-bold text-indigo-400 block">GARANTÍA FLOWFIT</span>
                <span className="text-xs text-white">Reuniones estratégicas mensuales de revisión de ROI</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
