import React, { useState } from 'react';
import { ShieldAlert, RefreshCcw, Heart, Smile, Sparkles, CheckSquare, Target } from 'lucide-react';
import { motion } from 'motion/react';

export default function PersonaAudit() {
  const [activeTab, setActiveTab] = useState<'dolor' | 'objecion' | 'deseo'>('dolor');
  
  // Interactive test state
  const [answers, setAnswers] = useState({
    agendaVacia: false,
    perdidoDinero: false,
    faltaTiempo: false,
    esceptico: false,
  });

  const [showResult, setShowResult] = useState(false);

  const calculateScore = () => {
    const checkedCount = Object.values(answers).filter(Boolean).length;
    if (checkedCount === 0) return { percent: 0, text: 'Tranquilidad Absoluta', desc: 'Tu negocio está en un punto óptimo, pero un sistema automatizado te ayudaría a escalar y liberar aún más tu tiempo.' };
    if (checkedCount === 1) return { percent: 25, text: 'Riesgo Moderado', desc: 'Tienes algún síntoma de estancamiento. Es el momento perfecto para blindar tu agenda antes de que sea tarde.' };
    if (checkedCount === 2) return { percent: 50, text: 'Inestabilidad de Ingresos', desc: 'Sufres de inestabilidad de ingresos. Trabajas duro pero dependes demasiado del boca a boca o de publicar sin rumbo en redes.' };
    if (checkedCount === 3) return { percent: 75, text: 'Saturación Crítica', desc: 'Tu agenda tiene demasiados vacíos preocupantes y sientes frustración con las redes sociales convencionales.' };
    return { percent: 100, text: 'Saturación y Escepticismo', desc: 'Has perdido dinero con agencias ineficaces, sientes agotamiento extremo y necesitas urgentemente nuestro Sistema de Captación con Resultados Garantizados.' };
  };

  const scoreResult = calculateScore();

  return (
    <section id="persona" className="py-24 bg-white border-t border-b border-slate-200 relative overflow-hidden">
      {/* Background Decorative Gradient */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 px-3 py-1 rounded-full">
            Diagnóstico de Captación y Garantía
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mt-4">
            ¿Te sientes identificado con esta situación?
          </h2>
          <p className="text-slate-600 mt-4 text-sm sm:text-base leading-relaxed">
            Muchos profesionales del sector deporte y salud han perdido miles de euros con agencias de marketing que solo entregaban "publicaciones estéticas" pero ningún paciente o cliente real. 
            Nosotros cambiamos las reglas del juego: <strong className="text-slate-900">garantizamos resultados reales por contrato</strong> para que solo te preocupes de atender tu consulta o centro.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Interactive Card with Tabs */}
          <div className="lg:col-span-7 bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-indigo-600"></div>
            
            <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2 mb-6">
              <Target className="text-indigo-600 w-5 h-5" />
              Análisis de Situación y Garantías del Servicio
            </h3>

            {/* Tabs Selector */}
            <div className="flex border-b border-slate-200 mb-8 overflow-x-auto whitespace-nowrap scrollbar-none">
              <button
                onClick={() => setActiveTab('dolor')}
                className={`flex items-center gap-2 px-4 py-3 text-xs uppercase tracking-wider font-bold border-b-2 transition-all duration-200 ${
                  activeTab === 'dolor'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                <ShieldAlert className="w-4 h-4" />
                El Obstáculo Principal
              </button>
              <button
                onClick={() => setActiveTab('objecion')}
                className={`flex items-center gap-2 px-4 py-3 text-xs uppercase tracking-wider font-bold border-b-2 transition-all duration-200 ${
                  activeTab === 'objecion'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                <RefreshCcw className="w-4 h-4" />
                La Objeción Habitual
              </button>
              <button
                onClick={() => setActiveTab('deseo')}
                className={`flex items-center gap-2 px-4 py-3 text-xs uppercase tracking-wider font-bold border-b-2 transition-all duration-200 ${
                  activeTab === 'deseo'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                <Heart className="w-4 h-4" />
                Tu Objetivo de Negocio
              </button>
            </div>

            {/* Tab Contents */}
            <div className="min-h-[220px] flex flex-col justify-between">
              {activeTab === 'dolor' && (
                <div className="animate-fadeIn">
                  <h4 className="text-lg font-bold text-slate-900 mb-2">Agenda vacía que no puedes permitirte</h4>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    Las nóminas de tus profesionales, el alquiler del local y los gastos fijos mensuales no perdonan. El "boca a boca" tradicional ya no es suficiente para asegurar la estabilidad económica ni justificar la inversión de tu equipo. Sientes frustración al ver huecos vacíos durante el día.
                  </p>
                  <div className="mt-6 bg-white p-4 rounded-lg border border-slate-200">
                    <span className="text-[11px] font-mono uppercase tracking-widest text-indigo-600 block mb-1">Impacto Real:</span>
                    <p className="text-slate-800 text-xs italic">"Cada hora sin citas es dinero perdido directamente del presupuesto de mi centro o clínica."</p>
                  </div>
                </div>
              )}

              {activeTab === 'objecion' && (
                <div className="animate-fadeIn">
                  <h4 className="text-lg font-bold text-slate-900 mb-2">"¿Qué os hace diferentes a las agencias que me han hecho perder dinero?"</h4>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    Muchos centros han contratado agencias generalistas que cobraban cientos de euros por subir imágenes prefabricadas y frases motivacionales. Nosotros no vendemos publicaciones vacías ni "likes" de adorno. Firmamos un compromiso y una garantía real de resultados por escrito.
                  </p>
                  <div className="mt-6 bg-white p-4 rounded-lg border border-slate-200">
                    <span className="text-[11px] font-mono uppercase tracking-widest text-emerald-600 block mb-1">Nuestra Garantía Directa:</span>
                    <p className="text-slate-800 text-xs italic">"No pagas por esfuerzos. Pagas por resultados: un flujo constante de reservas reales y de alta calidad para tu agenda."</p>
                  </div>
                </div>
              )}

              {activeTab === 'deseo' && (
                <div className="animate-fadeIn">
                  <h4 className="text-lg font-bold text-slate-900 mb-2">Foco en tus pacientes mientras tu agenda se llena en piloto automático</h4>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    Tu verdadero objetivo es poder delegar por completo la captación a un socio de confianza. Deseas llegar a tu consulta por la mañana, centrarte únicamente en ofrecer el mejor servicio y ver cómo tu sistema de captación sigue funcionando de forma constante y predecible.
                  </p>
                  <div className="mt-6 bg-white p-4 rounded-lg border border-slate-200">
                    <span className="text-[11px] font-mono uppercase tracking-widest text-indigo-600 block mb-1">Tu Estado de Tranquilidad:</span>
                    <p className="text-slate-800 text-xs italic">"Agenda organizada con semanas de antelación y la seguridad mental de que las finanzas de tu negocio están blindadas."</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Interactive self-assessment tool */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              <span className="p-1.5 bg-indigo-50 text-indigo-600 rounded">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </span>
              <h3 className="text-lg font-bold text-slate-900">Autoevaluación de Tu Centro</h3>
            </div>
            
            <p className="text-slate-500 text-xs mb-6">
              Selecciona los problemas que afectan actualmente a tu negocio de salud o deporte para medir tu nivel de riesgo de captación:
            </p>

            <div className="space-y-4 mb-6">
              <label className="flex items-start gap-3 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={answers.agendaVacia}
                  onChange={(e) => {
                    setAnswers({ ...answers, agendaVacia: e.target.checked });
                    setShowResult(true);
                  }}
                  className="mt-1 accent-indigo-600 w-4 h-4 rounded"
                />
                <span className="text-slate-600 group-hover:text-slate-900 text-xs transition-colors">
                  Tengo horas muertas o huecos vacíos recurrentes en mi agenda semanal.
                </span>
              </label>

              <label className="flex items-start gap-3 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={answers.perdidoDinero}
                  onChange={(e) => {
                    setAnswers({ ...answers, perdidoDinero: e.target.checked });
                    setShowResult(true);
                  }}
                  className="mt-1 accent-indigo-600 w-4 h-4 rounded"
                />
                <span className="text-slate-600 group-hover:text-slate-900 text-xs transition-colors">
                  He gastado dinero en agencias de redes sociales sin ver un retorno medible.
                </span>
              </label>

              <label className="flex items-start gap-3 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={answers.faltaTiempo}
                  onChange={(e) => {
                    setAnswers({ ...answers, faltaTiempo: e.target.checked });
                    setShowResult(true);
                  }}
                  className="mt-1 accent-indigo-600 w-4 h-4 rounded"
                />
                <span className="text-slate-600 group-hover:text-slate-900 text-xs transition-colors">
                  No tengo tiempo para grabar vídeos, editar Reels o escribir posts de venta.
                </span>
              </label>

              <label className="flex items-start gap-3 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={answers.esceptico}
                  onChange={(e) => {
                    setAnswers({ ...answers, esceptico: e.target.checked });
                    setShowResult(true);
                  }}
                  className="mt-1 accent-indigo-600 w-4 h-4 rounded"
                />
                <span className="text-slate-600 group-hover:text-slate-900 text-xs transition-colors">
                  Siento escepticismo sobre si el marketing digital realmente funciona en mi nicho.
                </span>
              </label>
            </div>

            {showResult && (
              <div className="bg-indigo-50/40 border border-indigo-100 rounded-xl p-4 animate-fadeIn">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono font-bold text-slate-500">Tu Nivel de Riesgo:</span>
                  <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded border ${
                    scoreResult.percent >= 75 ? 'bg-rose-50 text-rose-600 border-rose-100' : 
                    scoreResult.percent >= 50 ? 'bg-amber-50 text-amber-700 border-amber-100' : 
                    'bg-emerald-50 text-emerald-700 border-emerald-100'
                  }`}>
                    {scoreResult.text}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mb-3">
                  <div 
                    className="bg-indigo-600 h-full transition-all duration-500" 
                    style={{ width: `${scoreResult.percent}%` }}
                  ></div>
                </div>

                <p className="text-slate-700 text-xs leading-relaxed mb-4">
                  {scoreResult.desc}
                </p>

                <div className="text-[10px] text-slate-600 bg-white p-2.5 rounded border border-slate-200 flex flex-col gap-1">
                  <div className="flex items-center gap-1.5 text-emerald-600 font-bold uppercase tracking-wider text-[9px]">
                    <span>✓</span> <span>GARANTÍA TOTAL DE RESULTADOS</span>
                  </div>
                  <span>Reembolso total de la inversión de Setup si no consigues reservas calificadas en los primeros 30 días. Tu riesgo es cero.</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
