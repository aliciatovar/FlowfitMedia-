import React, { useState, useEffect } from 'react';
import { Calculator, DollarSign, TrendingUp, HelpCircle, ArrowRight, ShieldCheck } from 'lucide-react';

export default function RoiCalculator() {
  const [ticket, setTicket] = useState<number>(65); // Default ticket (65€ e.g., premium physio or personal training pack)
  const [newClients, setNewClients] = useState<number>(15); // Default new clients per month
  const [adBudget, setAdBudget] = useState<number>(450); // Ad budget (default 450€/month)
  const [businessType, setBusinessType] = useState<string>('fisioterapia');

  // Automatically adjust default tickets based on business type selection
  useEffect(() => {
    switch (businessType) {
      case 'fisioterapia':
        setTicket(65);
        setNewClients(15);
        break;
      case 'gimnasios':
        setTicket(250); // Pack or multi-month fee
        setNewClients(20);
        break;
      case 'clinicas':
        setTicket(800); // High ticket treatment
        setNewClients(8);
        break;
      case 'nutricionistas':
        setTicket(120); // Multi-session pack
        setNewClients(12);
        break;
      case 'entrenadores':
        setTicket(180); // Monthly personal training pack
        setNewClients(12);
        break;
    }
  }, [businessType]);

  // Calculations
  const agencyFee = 900; // Plan Crecimiento is 900/month
  const totalInvestment = agencyFee + adBudget;
  const extraMonthlyBilling = ticket * newClients;
  const netMonthlyProfit = Math.max(0, extraMonthlyBilling - totalInvestment);
  const annualBilling = extraMonthlyBilling * 12;
  const roiMultiplier = totalInvestment > 0 ? (extraMonthlyBilling / totalInvestment).toFixed(1) : '0';

  return (
    <section id="calculadora" className="py-24 bg-white border-t border-b border-slate-200 relative">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 px-3 py-1 rounded-full">
            Estrategia de Rentabilidad
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mt-4">
            Calculadora Interactiva de Retorno de Inversión (ROI)
          </h2>
          <p className="text-slate-600 mt-4 text-sm sm:text-base">
            No hablemos del coste del servicio; hablemos del <strong className="text-slate-900">retorno financiero</strong>. Si tu negocio factura entre 20.000 € y 60.000 €/mes, un sistema automático de captación se amortiza rápidamente.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          {/* Controls Column */}
          <div className="lg:col-span-6 bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-sm">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <Calculator className="w-5 h-5 text-indigo-600" />
                <h3 className="text-lg font-bold text-slate-900">Configura tus Parámetros</h3>
              </div>

              {/* Business Select */}
              <div className="mb-6">
                <label className="block text-xs font-mono uppercase tracking-wider text-slate-500 mb-2">
                  Tipo de Negocio
                </label>
                <select
                  value={businessType}
                  onChange={(e) => setBusinessType(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg py-3 px-4 text-slate-800 text-sm focus:outline-none focus:border-indigo-600"
                >
                  <option value="fisioterapia">Clínica de Fisioterapia</option>
                  <option value="gimnasios">Gimnasio o Box de CrossFit</option>
                  <option value="clinicas">Clínica Médica Privada</option>
                  <option value="nutricionistas">Consulta de Nutrición</option>
                  <option value="entrenadores">Entrenador Personal / Centro Boutique</option>
                </select>
              </div>

              {/* Slider 1: Average Ticket */}
              <div className="mb-8">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-mono uppercase tracking-wider text-slate-500">
                    Ticket Promedio por Cliente/Tratamiento
                  </span>
                  <span className="text-sm font-extrabold text-slate-800 bg-white px-3 py-0.5 rounded border border-slate-200">
                    {ticket} €
                  </span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="3000"
                  step="5"
                  value={ticket}
                  onChange={(e) => setTicket(Number(e.target.value))}
                  className="w-full accent-indigo-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>20€</span>
                  <span>1.500€</span>
                  <span>3.000€</span>
                </div>
              </div>

              {/* Slider 2: New Clients/Month */}
              <div className="mb-8">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-mono uppercase tracking-wider text-slate-500">
                    Nuevos Clientes Captados al Mes
                  </span>
                  <span className="text-sm font-extrabold text-indigo-600 bg-indigo-50 px-3 py-0.5 rounded border border-indigo-100">
                    +{newClients} al mes
                  </span>
                </div>
                <input
                  type="range"
                  min="3"
                  max="100"
                  step="1"
                  value={newClients}
                  onChange={(e) => setNewClients(Number(e.target.value))}
                  className="w-full accent-indigo-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>3 clientes</span>
                  <span>50</span>
                  <span>100 clientes</span>
                </div>
              </div>

              {/* Slider 3: Ad Budget */}
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-mono uppercase tracking-wider text-slate-500">
                    Presupuesto Mensual para Publicidad (Google/Meta)
                  </span>
                  <span className="text-sm font-extrabold text-slate-800 bg-white px-3 py-0.5 rounded border border-slate-200">
                    {adBudget} €
                  </span>
                </div>
                <input
                  type="range"
                  min="150"
                  max="2000"
                  step="50"
                  value={adBudget}
                  onChange={(e) => setAdBudget(Number(e.target.value))}
                  className="w-full accent-indigo-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>150€/mes</span>
                  <span>1.000€</span>
                  <span>2.000€/mes</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-200 text-[10px] text-slate-400 italic flex items-center gap-2">
              <span>*Los valores se calculan bajo una tarifa fija de mantenimiento del Plan Crecimiento (900€/mes).</span>
            </div>
          </div>

          {/* Results Column */}
          <div className="lg:col-span-6 bg-slate-900 border border-slate-850 rounded-2xl p-6 sm:p-8 flex flex-col justify-between relative overflow-hidden shadow-lg text-white">
            {/* Corner Accent Graphic */}
            <div className="absolute top-0 right-0 bg-indigo-600 text-white font-mono font-bold text-[10px] uppercase tracking-widest px-4 py-1.5 rounded-bl-xl shadow">
              ESTUDIO FINANCIERO ESTIMADO
            </div>

            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono uppercase tracking-widest text-indigo-400 block mb-1">Impacto de Facturación</span>
                <h3 className="text-2xl font-extrabold text-white tracking-tight">Análisis de Retorno Anual</h3>
              </div>

              {/* Big Metric Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Monthly Billing */}
                <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-xl">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-1">Facturación Adicional Mensual</span>
                  <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-baseline gap-1">
                    <span>{extraMonthlyBilling.toLocaleString()}</span>
                    <span className="text-sm font-bold text-slate-500">€</span>
                  </div>
                </div>

                {/* Annual Billing */}
                <div className="bg-slate-950/60 border border-indigo-950 p-4 rounded-xl">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-1">Facturación Adicional Anual</span>
                  <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-baseline gap-1">
                    <span className="text-emerald-400">{annualBilling.toLocaleString()}</span>
                    <span className="text-sm font-bold text-emerald-400">€</span>
                  </div>
                </div>
              </div>

              {/* Detail Financial Lines */}
              <div className="space-y-3 bg-slate-950/30 p-4 rounded-xl border border-slate-800">
                <div className="flex justify-between items-center text-xs text-slate-300">
                  <span>Mantenimiento Agencia (Plan Crecimiento):</span>
                  <span className="font-mono text-white">{agencyFee} €/mes</span>
                </div>
                <div className="flex justify-between items-center text-xs text-slate-300">
                  <span>Inversión Publicitaria Sugerida:</span>
                  <span className="font-mono text-white">{adBudget} €/mes</span>
                </div>
                <div className="border-t border-slate-800 my-2 pt-2 flex justify-between items-center text-xs font-bold text-white">
                  <span>Inversión Mensual Total:</span>
                  <span className="font-mono text-indigo-400">{totalInvestment} €/mes</span>
                </div>
                <div className="flex justify-between items-center text-xs font-bold text-white">
                  <span>Beneficio Neto Adicional Estimado:</span>
                  <span className="font-mono text-emerald-400">+{netMonthlyProfit.toLocaleString()} €/mes</span>
                </div>
              </div>

              {/* ROI Factor Block */}
              <div className="bg-indigo-600 rounded-xl p-5 text-white flex items-center justify-between relative overflow-hidden">
                <div className="absolute right-0 bottom-0 translate-x-1/3 translate-y-1/3 opacity-10">
                  <Calculator className="w-40 h-40" />
                </div>
                <div className="relative z-10">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-indigo-100 block mb-1">
                    Multiplicador de Retorno de Inversión (ROI)
                  </span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-black tracking-tighter">{roiMultiplier}x</span>
                    <span className="text-xs font-bold font-mono">de retorno</span>
                  </div>
                  <p className="text-[11px] text-indigo-100 mt-1">
                    Por cada euro invertido, generas {roiMultiplier}€ en tu negocio.
                  </p>
                </div>
                <div className="hidden sm:block">
                  <div className="bg-white/10 p-3 rounded-lg border border-white/20">
                    <TrendingUp className="w-8 h-8 text-white" />
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Análisis financiero basado en históricos reales</span>
              </div>
              <a 
                href="#contacto"
                className="w-full sm:w-auto text-center font-bold text-xs uppercase tracking-wider bg-white hover:bg-slate-100 text-slate-950 px-5 py-3 rounded-md transition-colors inline-flex items-center justify-center gap-2"
              >
                <span>Obtener Mi Auditoría de ROI</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
