import React, { useState } from 'react';
import { ContactFormData } from '../types';
import { Send, CheckCircle2, Search, Sparkles, MessageSquare, AlertCircle, Loader2 } from 'lucide-react';

export default function ContactForm() {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    phone: '',
    businessName: '',
    businessType: 'fisioterapia',
    website: '',
    currentClients: '10-30',
    biggestChallenge: '',
    acceptTerms: true,
  });

  const [loading, setLoading] = useState<boolean>(false);
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!formData.name || !formData.email || !formData.phone || !formData.businessName) {
      setError('Por favor, rellena los campos obligatorios (*).');
      return;
    }

    if (!formData.acceptTerms) {
      setError('Debes aceptar las políticas de privacidad.');
      return;
    }

    setLoading(true);

    // Simulate analysis and API post
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1800);
  };

  const getNicheLabel = (id: string) => {
    switch (id) {
      case 'fisioterapia': return 'Clínica de Fisioterapia';
      case 'gimnasios': return 'Gimnasio o Centro Deportivo';
      case 'clinicas': return 'Clínica Privada de Salud';
      case 'nutricionistas': return 'Consulta de Nutrición';
      case 'entrenadores': return 'Entrenamiento Personal';
      default: return 'Sector Deporte/Salud';
    }
  };

  const getCustomRecommendation = (type: string) => {
    switch (type) {
      case 'fisioterapia':
        return {
          title: 'Estrategia SEO Local Prioritaria',
          desc: 'Hemos detectado que en fisioterapia, el 72% de los pacientes reservan tras comparar reseñas locales en Google Maps. Durante nuestra sesión, analizaremos vuestros 3 mayores competidores en tu ciudad.',
          keywords: ['fisioterapeuta deportivo', 'clínica de fisioterapia cerca de mí', 'rehabilitación de lesiones']
        };
      case 'gimnasios':
        return {
          title: 'Estrategia de Embudo de Captación Express',
          desc: 'Los centros deportivos ganan tracción mediante promociones de entrada de bajo compromiso (como semanas de prueba gratuitas o cuotas reducidas el primer mes). Evaluaremos tu capacidad de retención para estructurar una oferta de alto impacto.',
          keywords: ['mejor box crossfit', 'gimnasio tarifas', 'entrenamiento de fuerza']
        };
      case 'clinicas':
        return {
          title: 'Estrategia de Autoridad y Confianza Médica',
          desc: 'Para clínicas privadas, la publicidad agresiva reduce el valor percibido. Te propondremos un embudo de diagnóstico interactivo y videos cortos explicativos de patologías específicas para posicionar a tu equipo como líderes de opinión.',
          keywords: ['especialidades médicas privadas', 'tratamientos regenerativos', 'clínica privada cita rápida']
        };
      case 'nutricionistas':
        return {
          title: 'Estrategia de Programas de Alto Valor',
          desc: 'Vender consultas sueltas de nutrición ahoga la rentabilidad. Te ayudaremos a diseñar planes mensuales cerrados de 12 semanas que incluyan soporte continuo por WhatsApp para multiplicar tus ingresos recurrentes.',
          keywords: ['dietista titulado', 'adelgazar de forma saludable', 'nutricionista deportivo']
        };
      case 'entrenadores':
        return {
          title: 'Estrategia de Segmentación Local Boutique',
          desc: 'Como entrenador personal, tu tiempo es limitado. Analizaremos cómo estructurar grupos reducidos en horarios de baja demanda o un modelo de asesoramiento híbrido presencial-digital de alta rentabilidad.',
          keywords: ['entrenador personal de rendimiento', 'entrenamiento funcional privado', 'preparador físico oposiciones']
        };
      default:
        return {
          title: 'Optimización de Embudo de Conversión',
          desc: 'Analizaremos tu huella digital actual para identificar dónde estás perdiendo posibles clientes que ya visitan tu web o redes sociales.',
          keywords: ['captación de clientes deporte', 'marketing digital salud']
        };
    }
  };

  const recommendation = getCustomRecommendation(formData.businessType);

  return (
    <section id="contacto" className="py-24 bg-white border-t border-slate-200 relative">
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left copy text (Expert SEO approach) */}
          <div className="lg:col-span-5 space-y-6">
            <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 px-3 py-1 rounded-full inline-block">
              Análisis Gratuito de Viabilidad
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Solicita tu Auditoría SEO y Plan de Captación Sin Coste
            </h2>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              No te enviaremos un PDF genérico automatizado. El director de estrategia de <strong className="text-slate-900">FlowfitMedia Agency</strong> analizará personalmente tu presencia en Google Maps, tus redes sociales actuales y a tu competencia local más fuerte.
            </p>

            <div className="space-y-4 pt-4">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-slate-50 rounded-lg border border-slate-200 text-indigo-600">
                  <Search className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Análisis de Competidores</h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-0.5">Detectamos exactamente de dónde consiguen clientes las otras clínicas o centros deportivos de tu zona.</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 bg-slate-50 rounded-lg border border-slate-200 text-emerald-600">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Diagnóstico de Embudo Local</h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-0.5">Medimos cuántas llamadas de venta o reservas estás perdiendo por falta de automatización.</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 bg-slate-50 rounded-lg border border-slate-200 text-amber-650">
                  <MessageSquare className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Simulador de Incremento de ROI</h4>
                  <p className="text-xs text-slate-500 leading-relaxed mt-0.5">Definimos la inversión exacta de publicidad requerida para cubrir la capacidad máxima de tu equipo.</p>
                </div>
              </div>
            </div>

            <div className="border-t border-slate-250 pt-6 text-xs text-slate-400 italic">
              *Nota: Solo admitimos un máximo de 3 clientes nuevos del mismo sector por área geográfica (ciudad/distrito) para evitar conflictos de interés en SEO Local y publicidad de pago.
            </div>
          </div>

          {/* Right form container */}
          <div className="lg:col-span-7">
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-indigo-600"></div>

              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="mb-4">
                    <h3 className="text-lg font-bold text-slate-900">Cuéntanos sobre tu Negocio</h3>
                    <p className="text-xs text-slate-500 mt-1">Completa los datos para personalizar tu llamada estratégica.</p>
                  </div>

                  {error && (
                    <div className="bg-rose-50 border border-rose-200 p-3 rounded-lg flex items-center gap-2 text-xs text-rose-600">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-500 mb-1.5">
                        Tu Nombre Completo *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Ej. Juan Pérez"
                        className="w-full bg-white border border-slate-200 rounded-lg py-2.5 px-3.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-500 mb-1.5">
                        Nombre de tu Clínica / Centro *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.businessName}
                        onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                        placeholder="Ej. Clínica Sanus o Box Apex"
                        className="w-full bg-white border border-slate-200 rounded-lg py-2.5 px-3.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-500 mb-1.5">
                        Correo Electrónico *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="ejemplo@clinicadeporte.com"
                        className="w-full bg-white border border-slate-200 rounded-lg py-2.5 px-3.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-500 mb-1.5">
                        Teléfono Móvil (WhatsApp) *
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="Ej. +34 600 000 000"
                        className="w-full bg-white border border-slate-200 rounded-lg py-2.5 px-3.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-500 mb-1.5">
                        Sector / Especialidad
                      </label>
                      <select
                        value={formData.businessType}
                        onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-lg py-2.5 px-3.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-600"
                      >
                        <option value="fisioterapia">Clínica de Fisioterapia / Osteopatía</option>
                        <option value="gimnasios">Gimnasio / Box CrossFit / Boutique</option>
                        <option value="clinicas">Clínica de Salud Privada / Estética</option>
                        <option value="nutricionistas">Consulta Nutrición / Dietista</option>
                        <option value="entrenadores">Entrenador Personal / Preparador</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-500 mb-1.5">
                        Página Web o Instagram actual
                      </label>
                      <input
                        type="text"
                        value={formData.website}
                        onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                        placeholder="Ej. www.miclinica.com o @miclinica"
                        className="w-full bg-white border border-slate-200 rounded-lg py-2.5 px-3.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-500 mb-1.5">
                      ¿Cuál es tu mayor obstáculo para conseguir clientes/pacientes actualmente?
                    </label>
                    <textarea
                      rows={3}
                      value={formData.biggestChallenge}
                      onChange={(e) => setFormData({ ...formData, biggestChallenge: e.target.value })}
                      placeholder="Ej. Invertimos en Facebook Ads pero solo conseguimos clics y comentarios, no agendan citas. El boca a boca se está frenando..."
                      className="w-full bg-white border border-slate-200 rounded-lg py-2.5 px-3.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600 resize-none"
                    />
                  </div>

                  <div className="flex items-start gap-2.5 pt-1">
                    <input
                      type="checkbox"
                      id="acceptTerms"
                      checked={formData.acceptTerms}
                      onChange={(e) => setFormData({ ...formData, acceptTerms: e.target.checked })}
                      className="mt-1 accent-indigo-600"
                    />
                    <label htmlFor="acceptTerms" className="text-[10px] text-slate-400 leading-normal">
                      Acepto el tratamiento de mis datos de contacto por FlowfitMedia para enviarme la auditoría estratégica gratuita y comunicarme detalles vía llamada/WhatsApp según el Reglamento General de Protección de Datos (RGPD).
                    </label>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-bold text-xs uppercase tracking-wider transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-indigo-100 disabled:opacity-50"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Analizando datos y viabilidad SEO...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Enviar y Reservar Diagnóstico Gratuito</span>
                      </>
                    )}
                  </button>
                </form>
              ) : (
                /* Success screen with custom strategy recommendation */
                <div className="p-4 sm:p-6 text-center space-y-6 animate-fadeIn">
                  <div className="w-16 h-16 bg-emerald-50 text-emerald-650 rounded-full flex items-center justify-center mx-auto border border-emerald-200">
                    <CheckCircle2 className="w-10 h-10 text-emerald-600" />
                  </div>

                  <div>
                    <h3 className="text-xl font-bold text-slate-900">¡Petición Recibida con Éxito, {formData.name}!</h3>
                    <p className="text-xs text-indigo-600 font-mono mt-1 uppercase tracking-widest">
                      FlowfitMedia ya está auditando a {formData.businessName}
                    </p>
                  </div>

                  <p className="text-xs text-slate-600 max-w-lg mx-auto leading-relaxed">
                    Hemos registrado tus datos del sector <strong className="text-slate-900">{getNicheLabel(formData.businessType)}</strong>. En las próximas 12-24 horas laborables, nuestro consultor jefe se pondrá en contacto contigo a través del móvil <strong className="text-slate-900">{formData.phone}</strong> o por correo ({formData.email}) para fijar el día de la videollamada de 15 minutos de diagnóstico.
                  </p>

                  {/* Dynamic strategy summary box! */}
                  <div className="bg-white border border-slate-200 rounded-xl p-5 text-left space-y-3 relative overflow-hidden shadow-sm">
                    <span className="text-[10px] font-mono font-bold text-indigo-600 uppercase tracking-wider bg-indigo-50 px-2.5 py-0.5 rounded">
                      RECOMENDACIÓN DE ENFOQUE INICIAL
                    </span>
                    
                    <h4 className="text-sm font-bold text-slate-900">
                      {recommendation.title}
                    </h4>
                    
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {recommendation.desc}
                    </p>

                    <div className="pt-2">
                      <span className="text-[10px] font-mono text-slate-400 block mb-1">Palabras clave locales que analizaremos:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {recommendation.keywords.map((kw, idx) => (
                          <span key={idx} className="text-[10px] bg-slate-50 text-slate-600 px-2 py-0.5 rounded border border-slate-200 font-mono">
                            "{kw}"
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => setSubmitted(false)}
                    className="text-xs text-slate-400 hover:text-slate-600 underline transition-colors"
                  >
                    Enviar otra solicitud o corregir datos
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
