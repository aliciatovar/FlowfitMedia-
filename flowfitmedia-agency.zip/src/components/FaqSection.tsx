import React, { useState } from 'react';
import { FAQS } from '../data';
import { ChevronDown, ChevronUp, HelpCircle, Search } from 'lucide-react';

export default function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    if (openIndex === index) {
      setOpenIndex(null);
    } else {
      setOpenIndex(index);
    }
  };

  return (
    <section id="faqs" className="py-24 bg-white border-t border-slate-200 relative">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 px-3 py-1 rounded-full">
            Resolución de Dudas Frecuentes
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mt-4">
            Preguntas Frecuentes y Enfoque SEO
          </h2>
          <p className="text-slate-600 mt-4 text-sm sm:text-base">
            Respondemos con total transparencia a las inquietudes más recurrentes de los propietarios de centros deportivos y clínicas de salud privada.
          </p>
        </div>

        {/* Faq List */}
        <div className="space-y-4">
          {FAQS.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden transition-colors duration-200"
              >
                <button
                  onClick={() => toggleFaq(idx)}
                  className="w-full flex items-center justify-between p-5 text-left text-slate-800 hover:text-indigo-650 focus:outline-none cursor-pointer"
                >
                  <div className="flex items-start gap-3">
                    <HelpCircle className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                    <span className="text-sm sm:text-base font-bold tracking-wide">
                      {faq.question}
                    </span>
                  </div>
                  <div>
                    {isOpen ? (
                      <ChevronUp className="w-5 h-5 text-indigo-600" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-slate-400" />
                    )}
                  </div>
                </button>

                {/* Answer Content */}
                {isOpen && (
                  <div className="px-5 pb-5 pt-1 border-t border-slate-200 animate-fadeIn">
                    <p className="text-slate-650 text-xs sm:text-sm leading-relaxed mb-4">
                      {faq.answer}
                    </p>

                    {/* SEO focus indicator */}
                    <div className="flex items-center gap-1.5 bg-white p-2.5 rounded border border-slate-200">
                      <Search className="w-3.5 h-3.5 text-indigo-600" />
                      <span className="text-[10px] font-mono text-slate-500">
                        Intención de búsqueda de esta respuesta: <strong className="text-slate-700">"{faq.seoKeywordFocus}"</strong>
                      </span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
