import React, { useEffect } from 'react';
import Navbar from './components/Navbar';
import NicheSelector from './components/NicheSelector';
import PersonaAudit from './components/PersonaAudit';
import RoiCalculator from './components/RoiCalculator';
import PricingSection from './components/PricingSection';
import ContactForm from './components/ContactForm';
import BrandStory from './components/BrandStory';
import FaqSection from './components/FaqSection';

// Icons for the custom feature list
import { 
  Search, 
  Instagram, 
  Target, 
  BarChart3, 
  TrendingUp, 
  Zap, 
  ShieldCheck, 
  ChevronRight, 
  MessageSquare,
  Award,
  BookOpen
} from 'lucide-react';

export default function App() {
  const handleScrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 80; // height of the fixed navbar
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  // Pre-load fonts and set initial document meta
  useEffect(() => {
    document.title = 'FlowfitMedia Agency - Más clientes para Deporte y Salud';
  }, []);

  return (
    <div className="bg-white text-slate-800 min-h-screen font-sans selection:bg-indigo-650 selection:text-white overflow-x-hidden antialiased">
      
      {/* Navigation Header */}
      <Navbar onScrollToSection={handleScrollToSection} />

      <main>
        {/* HERO SECTION */}
        <section id="hero" className="relative min-h-screen flex items-center pt-24 pb-16 overflow-hidden">
          {/* Background generated image overlay */}
          <div className="absolute inset-0 z-0">
            <img 
              src="/src/assets/images/modern_studio_hero_1783473108140.jpg" 
              alt="Premium Fitness Studio" 
              className="w-full h-full object-cover opacity-15 filter grayscale contrast-125"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-white via-white/90 to-transparent"></div>
            <div className="absolute inset-0 bg-gradient-to-r from-white via-white/70 to-transparent"></div>
          </div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              
              {/* Hero Main Copy */}
              <div className="lg:col-span-7 space-y-6 text-left">
                <div className="inline-flex items-center gap-2 bg-indigo-50 border border-indigo-100 rounded-full px-3 py-1 text-xs font-mono font-bold text-indigo-600 uppercase tracking-wider animate-pulse">
                  <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>
                  Agencia de Marketing Especializada en Deporte y Salud
                </div>

                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-slate-900 leading-[1.1]">
                  Más clientes. <br className="hidden sm:inline" />
                  Menos preocupaciones. <br className="hidden sm:inline" />
                  <span className="text-indigo-600">Más crecimiento.</span>
                </h1>

                <p className="text-slate-650 text-sm sm:text-base lg:text-lg max-w-xl leading-relaxed">
                  El sistema de captación diseñado a medida para <strong className="text-slate-900">clínicas de fisioterapia, gimnasios, nutricionistas y centros deportivos</strong> que quieren una agenda llena sin tener que dedicar horas diarias al marketing digital.
                </p>

                {/* Main Hero Actions */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
                  <button
                    onClick={() => handleScrollToSection('contacto')}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-lg font-bold text-xs sm:text-sm uppercase tracking-wider transition-all duration-300 shadow-xl shadow-indigo-100 flex items-center justify-center gap-2"
                  >
                    <span>Llenar Mi Agenda Ahora</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleScrollToSection('especialidades')}
                    className="border border-slate-200 hover:border-indigo-600 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 px-8 py-4 rounded-lg font-bold text-xs sm:text-sm uppercase tracking-wider transition-all duration-300 flex items-center justify-center gap-2"
                  >
                    <span>Ver Especialidades SEO</span>
                  </button>
                </div>

                {/* Micro social proof under actions */}
                <div className="pt-6 flex flex-wrap items-center gap-y-3 gap-x-6 border-t border-slate-100">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500">
                    <span className="text-indigo-600">✓</span>
                    <span>Sin permanencias absurdas</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500">
                    <span className="text-indigo-600">✓</span>
                    <span>Auditoría de competidores incluida</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500">
                    <span className="text-indigo-600">✓</span>
                    <span>Garantía de Citas Cualificadas</span>
                  </div>
                </div>
              </div>

              {/* Hero Dynamic Promo Dashboard Card */}
              <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-md relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl"></div>
                
                <div className="flex justify-between items-center mb-6">
                  <span className="text-[10px] font-mono font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 px-2 py-0.5 rounded">
                    ESTRATEGIAS ACTIVAS HOY
                  </span>
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                </div>

                <h3 className="text-lg font-bold text-slate-900 mb-2">Plan de Captación de Pacientes</h3>
                <p className="text-xs text-slate-500 mb-6">Un sistema que genera citas continuas en lugar de simples visualizaciones.</p>

                <div className="space-y-4">
                  {/* Item 1 */}
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="p-2 bg-indigo-50 text-indigo-600 rounded-lg text-xs font-mono font-bold">01</span>
                      <div>
                        <span className="text-xs font-bold text-slate-800 block">Posicionamiento SEO Local</span>
                        <span className="text-[10px] text-slate-400 block">Google Maps & Búsquedas directas</span>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-emerald-600">Alta Intención</span>
                  </div>

                  {/* Item 2 */}
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="p-2 bg-emerald-50 text-emerald-600 rounded-lg text-xs font-mono font-bold">02</span>
                      <div>
                        <span className="text-xs font-bold text-slate-800 block">Meta Ads / Embudo de Redes</span>
                        <span className="text-[10px] text-slate-400 block">Reels de conversión de alta retención</span>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-emerald-600">+150% Leads</span>
                  </div>

                  {/* Item 3 */}
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="p-2 bg-amber-50 text-amber-600 rounded-lg text-xs font-mono font-bold">03</span>
                      <div>
                        <span className="text-xs font-bold text-slate-800 block">Automatizaciones de Agenda</span>
                        <span className="text-[10px] text-slate-400 block">WhatsApp Express 24/7 sin esperas</span>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-indigo-600">Agenda Llena™</span>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 text-center">
                  <span className="text-[10px] text-slate-400 font-mono">
                    PROMEDIO DE RETORNO EN CLIENTES: <strong className="text-slate-700">4.5x ROI</strong>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* VALUE PROMOTION SIGNATURE STRIP (From manual de identidad pg 7) */}
        <section className="py-12 bg-slate-50 border-t border-b border-slate-200 relative">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center text-center md:text-left divide-y md:divide-y-0 md:divide-x divide-slate-200">
              
              <div className="py-4 md:py-0 md:pr-8">
                <span className="text-indigo-600 text-xs font-mono uppercase tracking-widest font-bold block mb-1">PROMINENCIA DE SERVICIO</span>
                <p className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight leading-snug">
                  "Tú cuidas a tus pacientes. <br className="hidden sm:inline" />
                  Nosotros llenamos tu agenda."
                </p>
              </div>

              <div className="py-4 md:py-0 md:pl-8">
                <span className="text-indigo-600 text-xs font-mono uppercase tracking-widest font-bold block mb-1">MÉTRICA DE OPERACIÓN</span>
                <p className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight leading-snug">
                  "El mejor marketing es el que genera <span className="text-indigo-600">citas reales</span>, no solo visitas vacías en tus perfiles."
                </p>
              </div>

            </div>
          </div>
        </section>

        {/* NICHE SELECTOR SECTION (SEO-Focused Specialty breakdown) */}
        <NicheSelector />

        {/* BUYER PERSONA EMOTIONAL SECTION (José Martínez analysis) */}
        <PersonaAudit />

        {/* METHODOLOGY SECTION: "Sistema Agenda Siempre Llena™" */}
        <section id="metodo" className="py-24 bg-white border-b border-slate-200 relative">
          <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 px-3 py-1 rounded-full">
                Nuestra Metodología Propietaria
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mt-4">
                El Sistema Agenda Siempre Llena™
              </h2>
              <p className="text-slate-650 mt-4 text-sm sm:text-base">
                Un sistema integral de captación diseñado exclusivamente para que tu clínica o centro deportivo genere solicitudes de citas sin que dependas de tu tiempo libre.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
              
              {/* Feature 1: Auditoría */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 hover:border-indigo-600/40 transition-all duration-300 flex flex-col justify-between shadow-sm">
                <div>
                  <div className="p-3 bg-white text-indigo-600 rounded-xl inline-block mb-5 border border-slate-205 shadow-sm">
                    <Search className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2">Auditoría Estratégica</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Análisis minucioso de competidores de tu área local, auditoría SEO de tu Google Business Profile y diagnóstico completo de fugas en tus redes sociales.
                  </p>
                </div>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest mt-6 block">Fase 1: Diagnóstico</span>
              </div>

              {/* Feature 2: Gestión de Redes */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 hover:border-indigo-600/40 transition-all duration-300 flex flex-col justify-between shadow-sm">
                <div>
                  <div className="p-3 bg-white text-indigo-600 rounded-xl inline-block mb-5 border border-slate-205 shadow-sm">
                    <Instagram className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2">Gestión de Redes Sociales</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Creación completa de 12 Reels, 8 carruseles estratégicos de alto valor de guardado y stories mensuales. Diseño gráfico prémium, guiones y copywriting de venta incluidos.
                  </p>
                </div>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest mt-6 block">Fase 2: Autoridad</span>
              </div>

              {/* Feature 3: Sistema de Captación */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 hover:border-indigo-600/40 transition-all duration-300 flex flex-col justify-between shadow-sm">
                <div>
                  <div className="p-3 bg-white text-indigo-600 rounded-xl inline-block mb-5 border border-slate-205 shadow-sm">
                    <Target className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2">Sistema de Captación</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Montaje y optimización de embudos publicitarios en Facebook, Instagram y Google Ads. Anuncios enfocados en convertir visitas en llamadas cualificadas de reserva.
                  </p>
                </div>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest mt-6 block">Fase 3: Conversión</span>
              </div>

              {/* Feature 4: Informe Mensual */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 hover:border-indigo-600/40 transition-all duration-300 flex flex-col justify-between shadow-sm">
                <div>
                  <div className="p-3 bg-white text-indigo-600 rounded-xl inline-block mb-5 border border-slate-205 shadow-sm">
                    <BarChart3 className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2">Informe Mensual de Negocio</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    No te informamos de seguidores ganados. Te mostramos el volumen de solicitudes de valoración inicial recibidas, leads calificados y la tasa de conversión final.
                  </p>
                </div>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest mt-6 block">Fase 4: Optimización</span>
              </div>

            </div>
          </div>
        </section>

        {/* ROI INTERACTIVE CALCULATOR */}
        <RoiCalculator />

        {/* PRICING SECTION */}
        <PricingSection />

        {/* RIESGOS Y MITIGACIÓN (Core Strategic Trust build) */}
        <section className="py-24 bg-slate-50 border-t border-b border-slate-200 relative">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 px-3 py-1 rounded-full">
                Transparencia Operativa Absoluta
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mt-4">
                Los 3 Riesgos Principales y Cómo los Mitigamos
              </h2>
              <p className="text-slate-650 mt-4 text-sm sm:text-base">
                Ninguna estrategia de marketing es mágica. Analizamos con total honestidad los factores de riesgo operativos para garantizar que tu inversión esté blindada.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Risk 1 */}
              <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between relative overflow-hidden shadow-sm">
                <div className="absolute top-0 right-0 bg-indigo-50 text-indigo-600 font-mono font-bold text-xs p-3 rounded-bl-xl border-l border-b border-slate-200">
                  01
                </div>
                <div>
                  <span className="text-xs font-mono font-bold text-indigo-600 uppercase tracking-wider block mb-3">
                    Riesgo de Dependencia Externa
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 mb-2 leading-tight">
                    Prometer resultados imposibles de controlar
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-6">
                    <strong>El Riesgo:</strong> El cliente espera una cifra fija de pacientes, pero el cierre de venta de ese paciente depende de la reputación local de tu clínica, del precio de tu tratamiento o de la velocidad del recepcionista para responder el teléfono.
                  </p>
                </div>
                <div className="bg-indigo-50/50 p-4 rounded-lg border border-indigo-100">
                  <span className="text-[10px] font-mono font-bold text-emerald-700 uppercase block mb-1">Nuestra Mitigación:</span>
                  <p className="text-xs text-slate-700">
                    Definimos desde el inicio las métricas bajo nuestro control directo (leads cualificados y llamadas concertadas). Firmamos un alcance de servicio claro y capacitamos gratis a tu recepcionista en guiones telefónicos express.
                  </p>
                </div>
              </div>

              {/* Risk 2 */}
              <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between relative overflow-hidden shadow-sm">
                <div className="absolute top-0 right-0 bg-indigo-50 text-indigo-600 font-mono font-bold text-xs p-3 rounded-bl-xl border-l border-b border-slate-200">
                  02
                </div>
                <div>
                  <span className="text-xs font-mono font-bold text-indigo-600 uppercase tracking-wider block mb-3">
                    Riesgo de Estructura Interna
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 mb-2 leading-tight">
                    Dependencia extrema del fundador del negocio
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-6">
                    <strong>El Riesgo:</strong> Si todo el marketing, la estrategia y el soporte al paciente dependen exclusivamente de tu persona, el crecimiento de tu clínica o box deportivo se detendrá drásticamente por saturación física de tu tiempo.
                  </p>
                </div>
                <div className="bg-indigo-50/50 p-4 rounded-lg border border-indigo-100">
                  <span className="text-[10px] font-mono font-bold text-emerald-700 uppercase block mb-1">Nuestra Mitigación:</span>
                  <p className="text-xs text-slate-700">
                    Documentamos todos los procesos de tu embudo (SOPs). Integramos tareas repetitivas mediante automatización con IA y herramientas como n8n, delegando primero el soporte rutinario para blindar tu tiempo clínico.
                  </p>
                </div>
              </div>

              {/* Risk 3 */}
              <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between relative overflow-hidden shadow-sm">
                <div className="absolute top-0 right-0 bg-indigo-50 text-indigo-600 font-mono font-bold text-xs p-3 rounded-bl-xl border-l border-b border-slate-200">
                  03
                </div>
                <div>
                  <span className="text-xs font-mono font-bold text-indigo-600 uppercase tracking-wider block mb-3">
                    Riesgo del Mercado Low-Cost
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 mb-2 leading-tight">
                    Competidores compitiendo por bajar el precio
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-6">
                    <strong>El Riesgo:</strong> El mercado está inundado de agencias tradicionales de bajo coste que ofrecen redes sociales baratas, forzando la bajada general de tarifas y ofreciendo un impacto nulo en facturación.
                  </p>
                </div>
                <div className="bg-indigo-50/50 p-4 rounded-lg border border-indigo-100">
                  <span className="text-[10px] font-mono font-bold text-emerald-700 uppercase block mb-1">Nuestra Mitigación:</span>
                  <p className="text-xs text-slate-700">
                    No competimos como "agencia barata de publicaciones". Nos posicionamos como socios comerciales. Diferenciamos tu marca diseñando ofertas premium y justificando tu tarifa mediante el Sistema Agenda Siempre Llena™.
                  </p>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* BRAND STORY */}
        <BrandStory />

        {/* FAQ ACCORDIONS SECTION */}
        <FaqSection />

        {/* CONTACT & STRATEGY LEADS FORM */}
        <ContactForm />
      </main>

      {/* FOOTER CORPORATIVO */}
      <footer className="bg-slate-900 border-t border-slate-950 py-16 text-slate-400 text-xs font-sans">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            
            {/* Column 1: Info */}
            <div className="space-y-4 col-span-1 md:col-span-1">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 flex items-center justify-center bg-indigo-600 rounded-lg">
                  <span className="font-extrabold text-white text-base tracking-tighter">FF</span>
                </div>
                <span className="font-bold text-white text-base tracking-wider">
                  FLOWFIT<span className="text-indigo-400">MEDIA</span>
                </span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Agencia de marketing digital de alto rendimiento especializada exclusivamente en el sector deportivo, salud y bienestar. Llenamos tu agenda, blindamos tu tiempo.
              </p>
            </div>

            {/* Column 2: Quick Links */}
            <div>
              <h4 className="text-white text-xs font-bold uppercase tracking-wider mb-4 font-mono">Estrategias</h4>
              <ul className="space-y-2.5 text-[11px]">
                <li><button onClick={() => handleScrollToSection('especialidades')} className="hover:text-indigo-400 transition-colors">Clínicas de Fisioterapia</button></li>
                <li><button onClick={() => handleScrollToSection('especialidades')} className="hover:text-indigo-400 transition-colors">Gimnasios y Centros Deportivos</button></li>
                <li><button onClick={() => handleScrollToSection('especialidades')} className="hover:text-indigo-400 transition-colors">Clínicas de Salud Privadas</button></li>
                <li><button onClick={() => handleScrollToSection('especialidades')} className="hover:text-indigo-400 transition-colors">Nutricionistas y Entrenadores</button></li>
              </ul>
            </div>

            {/* Column 3: Navigation */}
            <div>
              <h4 className="text-white text-xs font-bold uppercase tracking-wider mb-4 font-mono">Navegación</h4>
              <ul className="space-y-2.5 text-[11px]">
                <li><button onClick={() => handleScrollToSection('persona')} className="hover:text-indigo-400 transition-colors">¿Te identificas?</button></li>
                <li><button onClick={() => handleScrollToSection('metodo')} className="hover:text-indigo-400 transition-colors">Sistema Agenda Siempre Llena</button></li>
                <li><button onClick={() => handleScrollToSection('calculadora')} className="hover:text-indigo-400 transition-colors">Calculadora Interactiva ROI</button></li>
                <li><button onClick={() => handleScrollToSection('planes')} className="hover:text-indigo-400 transition-colors">Precios de Mantenimiento</button></li>
              </ul>
            </div>

            {/* Column 4: Legals & SEO focus */}
            <div className="space-y-3">
              <h4 className="text-white text-xs font-bold uppercase tracking-wider mb-4 font-mono">Contacto y Registro</h4>
              <p className="text-slate-300 text-[11px]">
                Sede central operativa en España. Proyectos locales en toda la Península Ibérica y asesoramientos de consultoría digital internacional.
              </p>
              <div className="bg-slate-950 border border-slate-800 p-2.5 rounded text-[10px] text-slate-300 flex items-center gap-1.5 font-mono">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>RGPD Compliant - Conexión Segura SSL</span>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] text-slate-400">
            <p>© {new Date().getFullYear()} FlowfitMedia Agency. Todos los derechos reservados. Diseñado bajo el Manual de Identidad de Marca Oficial.</p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-indigo-400">Aviso Legal</a>
              <a href="#" className="hover:text-indigo-400">Política de Privacidad</a>
              <a href="#" className="hover:text-indigo-400">Política de Cookies</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
