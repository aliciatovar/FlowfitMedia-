import { NicheInfo, PricingPlan, FaqItem } from './types';

export const NICHES: NicheInfo[] = [
  {
    id: 'fisioterapia',
    title: 'Clínicas de Fisioterapia',
    subtitle: 'SEO & Publicidad de Alta Conversión para Fisioterapeutas',
    icon: 'Activity',
    seoKeywords: [
      'fisioterapia cerca de mí',
      'fisioterapeuta especialista',
      'clínica de fisioterapia en mi ciudad',
      'tratamiento dolor de espalda',
    ],
    painPoints: [
      'Agenda con huecos vacíos y dependencia exclusiva de los referidos "boca a boca".',
      'Pérdida de dinero en publicidad que solo consigue "me gusta" pero ninguna reserva real.',
      'Pacientes que solo acuden en momentos de crisis agudas pero no realizan tratamientos preventivos.',
    ],
    solutions: [
      'Embudos automatizados para la reserva de citas de valoración inicial premium.',
      'Campañas locales segmentadas por patologías comunes (espalda, suelo pélvico, deportiva).',
      'Estrategia de posicionamiento SEO Local en Google Maps para dominar tu área geográfica.',
    ],
    caseStudyMock: {
      client: 'FisioMálaga & Bienestar',
      metrics: '+45 Nuevos Pacientes/Mes',
      duration: '90 Días',
      quote: 'Duplicamos nuestras consultas privadas y finalmente pudimos contratar a un fisioterapeuta de apoyo gracias al flujo constante de reservas.',
    },
  },
  {
    id: 'gimnasios',
    title: 'Gimnasios y Centros Deportivos',
    subtitle: 'Campañas de Captación Masiva y Retención de Socios',
    icon: 'Dumbbell',
    seoKeywords: [
      'mejor gimnasio',
      'gimnasio de alta intensidad',
      'matrícula gimnasio promoción',
      'clases de fitness dirigidas',
    ],
    painPoints: [
      'Alta tasa de rotación de clientes (socios que se desapuntan después del primer mes).',
      'Guerra de precios con gimnasios low-cost de grandes cadenas.',
      'Dificultad para vender cuotas anuales o programas de alto valor.',
    ],
    solutions: [
      'Campañas de anuncios con ofertas irresistibles (semana de prueba con garantía de resultados).',
      'Sistemas automatizados de nutrición y motivación para aumentar la retención de socios.',
      'Campañas en redes sociales enfocadas en la comunidad y transformación real de los clientes.',
    ],
    caseStudyMock: {
      client: 'Apex Fitness Club',
      metrics: '+180 Nuevos Socios Registrados',
      duration: '60 Días',
      quote: 'Lanzamos la promoción de apertura del nuevo box y logramos cubrir el 100% del aforo proyectado antes de abrir las puertas físicas.',
    },
  },
  {
    id: 'clinicas',
    title: 'Clínicas de Salud Privadas',
    subtitle: 'Captación Ética y Posicionamiento de Autoridad Médica',
    icon: 'Heart',
    seoKeywords: [
      'clínica de salud privada',
      'especialista medicina estética',
      'médico privado cita rápida',
      'chequeo médico completo',
    ],
    painPoints: [
      'Necesidad de mantener una reputación intachable y ética profesional sin parecer "vendedores de humo".',
      'Pacientes indecisos ante tratamientos de alto coste o cirugías menores.',
      'Competencia desleal con clínicas low-cost que reducen la calidad del servicio.',
    ],
    solutions: [
      'Estrategia de contenidos de autoridad médica en video formativo e informativo (Reels, YouTube).',
      'Sistemas de nutrición y captación con embudos de alta seguridad de datos.',
      'Gestión activa de reseñas positivas y SEO Local para tratamientos específicos de alto ticket.',
    ],
    caseStudyMock: {
      client: 'Clínica Médica Seneb',
      metrics: 'ROI de 4.2x en Publicidad',
      duration: '4 Meses',
      quote: 'Hemos logrado captar pacientes para tratamientos de medicina regenerativa con un valor promedio de 1.200€ por tratamiento.',
    },
  },
  {
    id: 'nutricionistas',
    title: 'Nutricionistas y Dietistas',
    subtitle: 'Llenado de Consultas Presenciales y de Asesoramiento Online',
    icon: 'Apple',
    seoKeywords: [
      'nutricionista nutrición clínica',
      'dietista para perder peso',
      'planes de alimentación personalizados',
      'consulta nutrición online',
    ],
    painPoints: [
      'Pacientes que abandonan la dieta al no ver resultados instantáneos o perder la motivación.',
      'Dificultad para posicionarse por encima del ruido de dietas milagro sin base científica.',
      'Baja rentabilidad si solo se cobran consultas individuales sueltas.',
    ],
    solutions: [
      'Evolución del modelo de "sesión suelta" a "programas mensuales de cambio de hábitos" de alto valor.',
      'Embudo con auto-evaluación interactiva de hábitos saludables para captación directa.',
      'Posicionamiento orgánico de Instagram centrado en desmentir mitos de nutrición mediante reels.',
    ],
    caseStudyMock: {
      client: 'NutriSana Online',
      metrics: '35 Nuevas Mentorías Mensuales',
      duration: '30 Días',
      quote: 'FlowfitMedia estructuró mi programa de 12 semanas. Pasé de cobrar 45€ por consulta a vender un programa integral de 250€ con lista de espera.',
    },
  },
  {
    id: 'entrenadores',
    title: 'Entrenadores Personales',
    subtitle: 'Estrategias para Entrenamientos Personales Premium y Grupos Reducidos',
    icon: 'Award',
    seoKeywords: [
      'entrenador personal a domicilio',
      'entrenamiento personalizado',
      'preparador físico oposiciones',
      'entrenamiento funcional de alta calidad',
    ],
    painPoints: [
      'Límite físico de horas diarias para entrenar (techo de facturación del profesional).',
      'Clientes que cancelan a última hora sin previo aviso y arruinan la planificación semanal.',
      'Dificultad para justificar tarifas premium mayores a 50€/hora en el mercado general.',
    ],
    solutions: [
      'Creación e implementación de planes de entrenamiento híbridos (presencial + seguimiento digital).',
      'Optimización de Google Business Profile para destacar como el entrenador mejor valorado del barrio.',
      'Automatización de cobros y políticas de cancelación para blindar el tiempo del profesional.',
    ],
    caseStudyMock: {
      client: 'EP Juan Carlos Silva',
      metrics: 'Saturación de Agenda y +120% Ingresos',
      duration: '60 Días',
      quote: 'Llené todos mis turnos de la mañana y creé un grupo de entrenamiento funcional corporativo con empresas locales que me genera ingresos fijos.',
    },
  },
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'esencial',
    name: 'Plan Esencial',
    price: '700',
    description: 'Ideal para clínicas y centros deportivos que quieren delegar la gestión profesional de sus redes sociales con contenido de alta calidad.',
    features: [
      'Gestión completa de Instagram y Facebook',
      '8 Publicaciones prémium + 4 Reels mensuales',
      'Calendario editorial estratégico personalizado',
      'Copywriting y diseño gráfico a medida',
      'Auditoría y optimización inicial de perfiles',
      'Informe mensual de crecimiento y métricas',
    ],
  },
  {
    id: 'crecimiento',
    name: 'Plan Crecimiento',
    price: '900',
    description: 'El plan de mayor impacto. Diseñado para clínicas y gimnasios que quieren crecer de forma constante mediante embudos de captación agresivos.',
    badge: 'MÁS RECOMENDADO',
    isPopular: true,
    features: [
      'Todo lo incluido en el Plan Esencial',
      'Inversión inicial única: Setup de 1.500€',
      'Embudo de Captación automatizado a medida',
      'Campañas de anuncios Meta Ads & Google Ads (presupuesto aparte)',
      'Optimización completa de Google Business Profile (SEO Local)',
      'Integración con WhatsApp Business para agendamiento express',
      '1 Reunión mensual de consultoría estratégica individual',
    ],
  },
  {
    id: 'premium',
    name: 'Plan Elite Premium',
    price: '1.400',
    description: 'Para negocios de salud y deporte consolidados que buscan dominar completamente su mercado geográfico y automatizar su servicio.',
    features: [
      'Todo lo incluido en el Plan Crecimiento',
      'Inversión inicial única: Setup de 3.500€',
      'Integración de IA para atención inicial de leads 24/7',
      'Montaje de CRM (HubSpot/ActiveCampaign) a medida',
      'Campañas automatizadas de reactivación de pacientes inactivos',
      'Automatización avanzada de confirmación y recordatorio de citas',
      'Dashboard interactivo de métricas de negocio en tiempo real',
      'Soporte prioritario 24h vía WhatsApp',
    ],
  },
];

export const FAQS: FaqItem[] = [
  {
    question: '¿Por qué vuestra agencia es diferente a otras agencias de marketing digital tradicionales?',
    answer: 'La mayoría de las agencias de marketing entregan lo que llamamos "métrica de vanidad": publicaciones bonitas, seguidores e interacciones sin impacto. Nosotros nos enfocamos en el negocio. No te vendemos "likes", te vendemos citas en tu calendario y nuevos miembros en tu base de datos. Además, somos ultra-especializados en el sector Deporte y Salud, por lo que entendemos perfectamente a tu paciente/cliente y la normativa médica.',
    seoKeywordFocus: 'agencia de marketing deportivo y salud profesional',
  },
  {
    question: '¿Cuánto tiempo tardaré en ver resultados reales en mi agenda?',
    answer: 'Las campañas de captación del Plan Crecimiento y Premium suelen activarse por completo a los 15-21 días tras la fase inicial de auditoría y configuración (Setup). Las primeras solicitudes de citas suelen llegar en la primera semana de encendido de campañas publicitarias. El posicionamiento SEO a largo plazo muestra su pico de rendimiento a partir del tercer y cuarto mes.',
    seoKeywordFocus: 'conseguir pacientes para fisioterapia rápido',
  },
  {
    question: '¿Tengo que dedicarle yo tiempo a crear vídeos o fotos?',
    answer: 'No. El sistema está diseñado para que te centres en atender a tus clientes o pacientes. Nosotros nos encargamos del guion, las plantillas de diseño, los textos de venta y el calendario. En caso de requerir material propio (como vídeos de tus tratamientos), te facilitamos un guion de 10 segundos detallado y pautas de grabación sencillas para que puedas grabarlo con tu móvil en menos de 30 minutos al mes.',
    seoKeywordFocus: 'marketing digital para gimnasios sin tiempo',
  },
  {
    question: '¿La inversión en publicidad (Meta Ads / Google Ads) está incluida en la cuota?',
    answer: 'No, el presupuesto destinado a los anuncios de pago va directamente a las plataformas publicitarias (Meta o Google) mediante tu tarjeta de facturación, lo que garantiza total transparencia. Recomendamos empezar con un presupuesto publicitario mínimo de 10€ a 15€ al día para garantizar un volumen de datos óptimo que alimente tu sistema de captación.',
    seoKeywordFocus: 'presupuesto publicidad clínica privada de salud',
  },
  {
    question: '¿Existe algún compromiso de permanencia en vuestros planes?',
    answer: 'Creemos plenamente en la calidad de nuestro trabajo. El Plan Esencial no tiene permanencia (puedes cancelarlo mes a mes). Para el Plan Crecimiento y Elite Premium, sugerimos una permanencia mínima de 3 meses tras el Setup inicial, ya que es el tiempo necesario para optimizar al máximo los algoritmos de captación y asentar las bases del embudo automático.',
    seoKeywordFocus: 'agencia de marketing sin permanencia obligatoria',
  },
];
